# Databricks notebook source
# MAGIC %md
# MAGIC ###Bronze Layer

# COMMAND ----------

spark.conf.set(
  "fs.azure.account.key.prathamstorage3008.dfs.core.windows.net",
  "Ja2EqAdQ0CmADfp19cBWipqZA3so1OQj20sJ8ntGPn6lskY/uzolg90r/8koQ/dd56ugUIwjqtin+AStGTyueA=="
)
# :two: Load raw files into DataFrames
# Transactions (JSON)
df_transactions = spark.read.format("json").option("inferSchema", "true").option("header","true").load(
    "abfss://raw3008@prathamstorage3008.dfs.core.windows.net/transactions.json"
)

# Customers (Parquet)
df_customers = spark.read.parquet(
    "abfss://raw3008@prathamstorage3008.dfs.core.windows.net/customers.parquet"
)

# Merchants (Parquet)
df_merchants = spark.read.parquet(
    "abfss://raw3008@prathamstorage3008.dfs.core.windows.net/merchants.parquet"
)

# Blacklist (CSV)
df_blacklist = spark.read.option("header","true").csv(
    "abfss://raw3008@prathamstorage3008.dfs.core.windows.net/blacklist.csv"
)

# :three: Save as Bronze Delta tables
df_transactions.write.format("delta").mode("overwrite").saveAsTable("pratham_cat_3008.bronze.transactions_raw")
df_customers.write.format("delta").mode("overwrite").saveAsTable("pratham_cat_3008.bronze.customers_raw")
df_merchants.write.format("delta").mode("overwrite").saveAsTable("pratham_cat_3008.bronze.merchants_raw")
df_blacklist.write.format("delta").mode("overwrite").saveAsTable("pratham_cat_3008.bronze.blacklist_raw")

# :four: Query Bronze tables (optional)
display(spark.sql("SELECT * FROM pratham_cat_3008.bronze.transactions_raw LIMIT 10"))
display(spark.sql("SELECT * FROM pratham_cat_3008.bronze.customers_raw LIMIT 10"))
display(spark.sql("SELECT * FROM pratham_cat_3008.bronze.merchants_raw LIMIT 10"))
display(spark.sql("SELECT * FROM pratham_cat_3008.bronze.blacklist_raw LIMIT 10"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Layer

# COMMAND ----------

from pyspark.sql.functions import col, when

# Set Unity Catalog and schema
spark.sql("USE CATALOG pratham_cat_3008")
spark.sql("USE SCHEMA bronze")

# COMMAND ----------

df_customers = spark.read.table("customers_raw")

# COMMAND ----------

from pyspark.sql.functions import col, trim, when
df_customers_cleaned = (
    df_customers
    # 1. Remove NULL account_id
    .filter(col("account_id").isNotNull())
    # 2. Remove INVALID_* account_ids
    .filter(~col("account_id").startswith("INVALID_"))

    # 3. Trim spaces from all string cols
    .withColumn("account_id", trim(col("account_id")))
    .withColumn("name", trim(col("name")))
    .withColumn("demographic", trim(col("demographic")))
    .withColumn("kyc_status", trim(col("kyc_status")))
    
    # 4. Handle missing values: impute with 'UNKNOWN'
    .withColumn("name", when(col("name").isNull() | (col("name") == ""), "UNKNOWN").otherwise(col("name")))
    .withColumn("demographic", when(col("demographic").isNull() | (col("demographic") == ""), "UNKNOWN").otherwise(col("demographic")))
    .withColumn("kyc_status", when(col("kyc_status").isNull() | (col("kyc_status") == ""), "UNKNOWN").otherwise(col("kyc_status")))
    
    # 5. Drop duplicates
    .dropDuplicates()
)


# COMMAND ----------

df_customers_cleaned.write.mode("overwrite").format("delta").saveAsTable("pratham_cat_3008.silver.customers_raw_processed")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pratham_cat_3008.silver.customers_raw_processed

# COMMAND ----------

from pyspark.sql.functions import col, when, trim, lower, lit, count

# Read from bronze
df_merchants = spark.read.table("pratham_cat_3008.bronze.merchants_raw")

# 1. Remove invalid merchant_id rows
df_merchants = df_merchants.filter(
    (col("merchant_id").isNotNull()) & (~col("merchant_id").startswith("INVALID_"))
)

# 2. Clean mcc
# Find mode of mcc
mode_mcc = df_merchants.filter(
    (~col("mcc").isNull()) & (~col("mcc").startswith("INVALID_")) & (trim(col("mcc")) != "")
).groupBy("mcc").count().orderBy(col("count").desc()).first()[0]

df_merchants = df_merchants.withColumn(
    "mcc_imputed",
    when((col("mcc").isNull()) | (trim(col("mcc")) == "") | (col("mcc").startswith("INVALID_")), 1).otherwise(0)
).withColumn(
    "mcc",
    when((col("mcc").isNull()) | (trim(col("mcc")) == "") | (col("mcc").startswith("INVALID_")), lit(mode_mcc))
    .otherwise(col("mcc"))
)

# 3. Clean risk_rating
# Find mode of risk_rating
mode_risk = df_merchants.filter(
    (~col("risk_rating").isNull()) & (~col("risk_rating").startswith("INVALID_")) & (trim(col("risk_rating")) != "")
).groupBy("risk_rating").count().orderBy(col("count").desc()).first()[0]

df_merchants = df_merchants.withColumn(
    "risk_imputed",
    when((col("risk_rating").isNull()) | (trim(col("risk_rating")) == "") | (col("risk_rating").startswith("INVALID_")), 1).otherwise(0)
).withColumn(
    "risk_rating",
    when((col("risk_rating").isNull()) | (trim(col("risk_rating")) == "") | (col("risk_rating").startswith("INVALID_")), lit(mode_risk))
    .otherwise(col("risk_rating"))
)

# 4. Trim and standardize
df_merchants = df_merchants.withColumn("mcc", trim(col("mcc")))\
                           .withColumn("risk_rating", lower(trim(col("risk_rating"))))

# Drop duplicates
df_merchants = df_merchants.dropDuplicates()




# COMMAND ----------

# Save cleaned merchants into silver
df_merchants.write.mode("overwrite").format("delta").saveAsTable("pratham_cat_3008.silver.merchants_raw_processed")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pratham_cat_3008.silver.merchants_raw_processed

# COMMAND ----------



# Read blacklist from bronze
df_blacklist = spark.read.table("pratham_cat_3008.bronze.blacklist_raw")

# Cleaning steps
df_blacklist_cleaned = (
    df_blacklist
    # Remove null or invalid account_id
    .filter((col("account_id").isNotNull()) & (~col("account_id").startswith("INVALID_")))
    
    # Trim spaces
    .withColumn("account_id", trim(col("account_id")))
    
    # Remove duplicates
    .dropDuplicates()
    
)

# Save to silver schema
df_blacklist_cleaned.write.mode("overwrite").format("delta").saveAsTable("pratham_cat_3008.silver.blacklist_raw_processed")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pratham_cat_3008.silver.blacklist_raw_processed

# COMMAND ----------

from pyspark.sql.functions import to_timestamp, col
df = spark.read.table("pratham_cat_3008.bronze.transactions_raw")
# Convert timestamp to proper format (this will create NULL for invalid timestamps)
df_with_ts = df.withColumn("timestamp_clean", to_timestamp("timestamp"))

# Rows to archive: missing/invalid IDs or invalid timestamp
df_archive = df_with_ts.filter(
    (col("transaction_id").isNull()) | (col("account_id").isNull()) | (col("merchant_id").isNull()) |
    (col("transaction_id").startswith("INVALID_")) |
    (col("account_id").startswith("INVALID_")) |
    (col("merchant_id").startswith("INVALID_")) |
    (col("timestamp_clean").isNull())  # invalid timestamp
)

# COMMAND ----------

df_archive.write \
    .mode("overwrite") \
    .format("delta") \
    .saveAsTable("pratham_cat_3008.silver.transactions_archive")


# COMMAND ----------

# MAGIC %sql select * from pratham_cat_3008.silver.transactions_archive 

# COMMAND ----------

df_valid = df_with_ts.subtract(df_archive)

# COMMAND ----------

from pyspark.sql.functions import col, when, trim, lower, lit, count

for c in ["transaction_id", "account_id", "merchant_id", "currency", "location", "channel", "device_info"]:
    df_valid = df_valid.withColumn(c, trim(col(c)))

# 2. Amount: impute missing with median
median_amount = df_valid.approxQuantile("amount", [0.5], 0.01)[0]
df_valid = df_valid.withColumn("amount", when(col("amount").isNull(), median_amount).otherwise(col("amount")))

# 3. Currency: impute missing with mode
mode_currency = df_valid.groupBy("currency").count().orderBy(col("count").desc()).first()[0]
df_valid = df_valid.withColumn("currency", when(col("currency").isNull() | (col("currency") == ""), mode_currency).otherwise(col("currency")))

# 4. Fill other string columns
for c in ["location", "channel", "device_info"]:
    df_valid = df_valid.withColumn(c, when(col(c).isNull() | (col(c) == ""), "UNKNOWN").otherwise(col(c)))

# 5. is_fraud: fill missing with 0
df_valid = df_valid.withColumn("is_fraud", when(col("is_fraud").isNull(), 0).otherwise(col("is_fraud")))

# 6. Drop duplicates
df_cleaned = df_valid.dropDuplicates()

# 7. Save to silver
df_cleaned.write.mode("overwrite").format("delta").saveAsTable("pratham_cat_3008.silver.transactions_raw_processed")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pratham_cat_3008.silver.transactions_raw_processed

# COMMAND ----------

# Drop the invalid timestamp column
df_final = df.drop("timestamp")

# Save back to silver table
df_final.write.format("delta").mode("overwrite").saveAsTable("pratham_cat_3008.silver.transactions_raw_processed")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pratham_cat_3008.silver.transactions_raw_processed

# COMMAND ----------

# Transactions
df_transactions1 = spark.read.table("pratham_cat_3008.silver.transactions_raw_processed")

# Customers
df_customers1 = spark.read.table("pratham_cat_3008.silver.customers_raw_processed")

# Merchants
df_merchants1 = spark.read.table("pratham_cat_3008.silver.merchants_raw_processed")

# Blacklist
df_blacklist1 = spark.read.table("pratham_cat_3008.silver.blacklist_raw_processed")


# COMMAND ----------

from pyspark.sql.functions import col

df_joined_TC = df_transactions1.join(
    df_customers1,
    on="account_id",
    how="left"
)


# COMMAND ----------

df_joined_TCM = df_joined_TC.join(
    df_merchants1,
    on="merchant_id",
    how="left"
)


# COMMAND ----------

from pyspark.sql.functions import when

df_final_silver = df_joined_TCM.join(
    df_blacklist1,
    on="account_id",
    how="left"
).withColumn(
    "blacklist_flag",
    when(col("reason").isNotNull(), 1).otherwise(0)
).drop("reason") 



# COMMAND ----------

df_final_silver = df_final_silver.dropDuplicates()




# COMMAND ----------

# Drop the invalid timestamp column
df_final_silver = df_final_silver.drop("timestamp")

# COMMAND ----------

df_final_silver.write.format("delta").mode("overwrite").saveAsTable("pratham_cat_3008.silver.silver_final")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pratham_cat_3008.silver.silver_final

# COMMAND ----------

# MAGIC %md
# MAGIC ##Masking
# MAGIC __

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE pratham_cat_3008.silver_secure.customers_masked AS
# MAGIC SELECT 
# MAGIC     account_id,  -- keep
# MAGIC     regexp_replace(name, '(.*)', 'XXXX') AS name,
# MAGIC     demographic,  -- can keep (unless it contains sensitive info like age, gender etc.)
# MAGIC     kyc_status
# MAGIC FROM pratham_cat_3008.silver.customers_raw_processed;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pratham_cat_3008.silver_secure.customers_masked

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE pratham_cat_3008.silver_secure.transactions_masked AS
# MAGIC SELECT 
# MAGIC     transaction_id,
# MAGIC     account_id,
# MAGIC     merchant_id,
# MAGIC     timestamp,
# MAGIC     0 AS amount,  -- mask numeric with 0
# MAGIC     currency,
# MAGIC     regexp_replace(location, '(.*)', 'XXX') AS location,
# MAGIC     channel,
# MAGIC     regexp_replace(device_info, '(.*)', 'XXX') AS device_info,
# MAGIC     is_fraud
# MAGIC FROM pratham_cat_3008.silver.transactions_cleaned;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pratham_cat_3008.silver_secure.transactions_masked

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE pratham_cat_3008.silver_secure.silver_final_masked AS
# MAGIC SELECT
# MAGIC     transaction_id,
# MAGIC     regexp_replace(account_id, '(.*)', 'XXX') AS account_id,
# MAGIC     regexp_replace(merchant_id, '(.*)', 'XXX') AS merchant_id,
# MAGIC     0 AS amount,  -- mask numeric with 0
# MAGIC     channel,
# MAGIC     currency,
# MAGIC     regexp_replace(device_info, '(.*)', 'XXX') AS device_info,
# MAGIC     is_fraud,
# MAGIC     regexp_replace(location, '(.*)', 'XXX') AS location,
# MAGIC     timestamp,
# MAGIC     timestamp_clean,
# MAGIC     regexp_replace(name, '(.*)', 'XXX') AS name,
# MAGIC     regexp_replace(demographic, '(.*)', 'XXX') AS demographic,
# MAGIC     regexp_replace(kyc_status, '(.*)', 'XXX') AS kyc_status,
# MAGIC     mcc,
# MAGIC     risk_rating,
# MAGIC     mcc_imputed,
# MAGIC     risk_imputed,
# MAGIC     blacklist_flag
# MAGIC FROM pratham_cat_3008.silver.silver_final;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from pratham_cat_3008.silver_secure.silver_final_masked

# COMMAND ----------

# MAGIC %md
# MAGIC ## GOLD LAYER
# MAGIC

# COMMAND ----------

